qtdd1 = document.getElementById("qtdd1");
qtdd2 = document.getElementById("qtdd2");
qtdd3 = document.getElementById("qtdd3");
qtdd4 = document.getElementById("qtdd4");
botao = document.getElementById("botao");

qtdd = document.getElementById("qtdd");
preco = document.getElementById("preco");

function calculo() {
    totalquantidade = Number(qtdd1.value) + Number(qtdd2.value) + Number(qtdd3.value) + Number(qtdd4.value);
    totalPreco = Number(qtdd1.value*5.00) + Number(qtdd2.value*5.00) + Number(qtdd3.value*10.00) + Number(qtdd4.value*10.00);
    qtdd.innerHTML = totalquantidade;
    preco.innerHTML = totalPreco;
}

botao.addEventListener("click", calculo);